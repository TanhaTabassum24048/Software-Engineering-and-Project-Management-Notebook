import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;

public class Container {
    private final Map<String, Object> beans = new LinkedHashMap<>();

    public void scan(Class<?>... classes) {
        for (Class<?> type : classes) {
            Component component = type.getAnnotation(Component.class);
            if (component == null) {
                System.out.println("[Container] Skipped: " + type.getSimpleName()
                        + " (no @Component)");
                continue;
            }

            String beanName = component.value().trim();
            if (beanName.isEmpty()) {
                beanName = Character.toLowerCase(type.getSimpleName().charAt(0))
                        + type.getSimpleName().substring(1);
            }

            try {
                Constructor<?> constructor = type.getDeclaredConstructor();
                constructor.setAccessible(true);
                Object instance = constructor.newInstance();
                beans.put(beanName, instance);
                System.out.println("[Container] Registered: " + beanName
                        + " (" + type.getSimpleName() + ")");
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException(
                        "Could not create bean " + type.getName()
                                + ". A no-argument constructor is required.", e);
            }
        }
    }

    public void injectValues(Map<String, String> config) {
        for (Object bean : beans.values()) {
            Class<?> type = bean.getClass();
            for (Field field : type.getDeclaredFields()) {
                Value value = field.getAnnotation(Value.class);
                if (value == null) {
                    continue;
                }

                String configValue = config.get(value.value());
                if (configValue == null) {
                    throw new IllegalArgumentException(
                            "Missing configuration key: " + value.value());
                }

                try {
                    field.setAccessible(true);
                    if (field.getType() == String.class) {
                        field.set(bean, configValue);
                    } else if (field.getType() == int.class
                            || field.getType() == Integer.class) {
                        field.set(bean, Integer.parseInt(configValue));
                    } else {
                        throw new IllegalArgumentException(
                                "Unsupported @Value field type: " + field.getType());
                    }
                    System.out.println("[Container] Injected: " + value.value()
                            + " -> " + type.getSimpleName() + "." + field.getName());
                } catch (IllegalAccessException e) {
                    throw new IllegalStateException(
                            "Could not inject field " + field.getName(), e);
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException(
                            "Configuration value for " + value.value()
                                    + " is not a valid integer: " + configValue, e);
                }
            }
        }
    }

    public Object getBean(String name) {
        return beans.get(name);
    }

    // Used by Router to inspect all managed objects.
    public Map<String, Object> getBeans() {
        return java.util.Collections.unmodifiableMap(beans);
    }
}
